# NDCT
A compressor for nd-tensor with discrete cosine transform
