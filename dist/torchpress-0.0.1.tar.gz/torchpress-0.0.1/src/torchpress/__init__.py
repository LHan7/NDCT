from torchpress import ndct
__all__ = ["ndct"]
